
package com.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@SpringBootApplication
public class CourseManagementApplication {
    public static void main(String[] args) {
        SpringApplication.run(CourseManagementApplication.class, args);
    }

    @Configuration
    public class SecurityConfig {

        @Bean
        public InMemoryUserDetailsManager userDetailsService() {
            return new InMemoryUserDetailsManager(
                User.withDefaultPasswordEncoder()
                    .username("student")
                    .password("1234")
                    .roles("STUDENT")
                    .build(),
                User.withDefaultPasswordEncoder()
                    .username("admin")
                    .password("admin123")
                    .roles("ADMIN")
                    .build()
            );
        }

        @Bean
        public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
            http
                .authorizeHttpRequests()
                    .requestMatchers("/login", "/css/**").permitAll()
                    .anyRequest().authenticated()
                .and()
                .formLogin()
                    .loginPage("/login")
                    .defaultSuccessUrl("/dashboard", true)
                    .permitAll()
                .and()
                .logout()
                    .logoutSuccessUrl("/login?logout=true")
                    .permitAll();
            return http.build();
        }
    }

    @Controller
    public class AppController {

        @GetMapping("/login")
        public String login() {
            return "login";
        }

        @GetMapping("/dashboard")
        public String dashboard() {
            return "dashboard";
        }
    }
}
